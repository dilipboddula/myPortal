package comj.test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public interface EmpD {
abstract void getAllEmployees();
abstract boolean addEmployee(Employee e);
abstract Employee getEmployeeList();
	
}

class Test implements EmpD{
	String name;
	int id,sal;
	
	Connection con=null;
	@Override
	public void getAllEmployees() {
		
		con=(Connection) ModelDAO.connectdb();
		try {
			
			PreparedStatement ps=(PreparedStatement) con.prepareStatement("select * from employee");
			ps.execute();
			ResultSet s=ps.getResultSet();
			//System.out.println("table created"+s);
			while(s.next()){
				name=s.getString(1);
				id=s.getInt(2);
				sal=s.getInt(3);
				System.out.println(name+" "+id+" "+sal);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public boolean addEmployee(Employee e) {
		con=(Connection) ModelDAO.connectdb();
		PreparedStatement ps;
		try {
			ps = (PreparedStatement) con.prepareStatement("insert into Employee values(?,?,?)");
			ps.setString(1,e.getName());
			ps.setInt(2,e.getId());
			ps.setInt(3,e.getSal());
			ps.execute();
		
	
		
		}catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	
		
	

		return false;
	
}

	@Override
	public Employee getEmployeeList() {
		con=(Connection) ModelDAO.connectdb();
		PreparedStatement ps;
		int i=0;
		ArrayList<Employee> al=new ArrayList<Employee>();
		try {
			ps = (PreparedStatement) con.prepareStatement("select * from Employee");
	ResultSet s=ps.getResultSet();
	while(s.next()){
		i++;
		al.add(i, (Employee) s);
		
	}
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}
}