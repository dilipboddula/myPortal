package com.test;
import java.util.ArrayList;

public interface EmpDetails {
	
boolean addEmployee(Employee e);
ArrayList<Employee> getAllEmp();
Employee getEmpbyId(int id);

}

