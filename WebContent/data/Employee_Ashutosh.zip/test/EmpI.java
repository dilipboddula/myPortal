package com.test;

import java.util.ArrayList;
import java.util.Scanner;
import java.sql.*;
public class EmpI implements EmpDetails {

	
	@Override
	public boolean addEmployee(Employee e) {
		
		Connection con=ModelDAO.connectDB();
		Statement st=null;
		try{
			st=con.createStatement();
			String ins="insert into Employee values('"+e.name+"','"+e.id+"','"+e.sal+"');";
			boolean s=st.execute(ins);
			
		}
		catch(Exception e1)
		{
			e1.printStackTrace();
		}
		return false;
	}

	@Override
	public ArrayList<Employee> getAllEmp() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee getEmpbyId(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public static void main(String[] args) {
		Employee obj=new Employee();
		EmpI e=new EmpI();
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter id");
		obj.setId(sc.nextInt());
		System.out.println("Enter name");
		obj.setName(sc.next());
		System.out.println("Enter salary");
		obj.setSal(sc.nextInt());
		
		e.addEmployee(obj);
		
	}
}
