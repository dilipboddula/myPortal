package com.test;
import java.sql.*;

public class ModelDAO {

	static Connection conn;
	public static Connection connectDB(){
		try{
			String drivername="com.mysql.jdbc.Driver";
			try {
				Class.forName(drivername).newInstance();
			} catch (ClassNotFoundException e1) {
			
				e1.printStackTrace();
			}
			try {
				conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");
			} catch (SQLException e) {
		
				e.printStackTrace();
			}
		}
		catch(InstantiationException e){
			e.printStackTrace();
		}
		catch(IllegalAccessException e){
			e.printStackTrace();
		}
		return conn;
	}
	
}
