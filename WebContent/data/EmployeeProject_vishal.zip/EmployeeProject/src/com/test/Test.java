package com.test;

import java.util.Scanner;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Employee e2=new Employee();
		EmpDetails e3=new Imp();
		Scanner sc= new Scanner(System.in);
		e2.setName(sc.next());
		e2.setId(sc.nextInt());
		e2.setSal(sc.nextInt());
		e3.addEmployee(e2);
		e3.getAllEmployees();

	}

}
