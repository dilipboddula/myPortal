package com.assignment.employee;

public class Employee 
{
	String name;
	int salary;
	int id;
	public Employee(String name, int salary, int id) {
		super();
		this.name = name;
		this.salary = salary;
		this.id = id;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", salary=" + salary + ", id=" + id
				+ "]";
	}
	
}
