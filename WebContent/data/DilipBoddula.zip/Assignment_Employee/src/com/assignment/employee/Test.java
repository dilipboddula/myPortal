package com.assignment.employee;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Test 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		String name;
		int id,salary;
		int choice;
		EmpImpl a=new EmpImpl();
		Employee e;
		do{
			System.out.println("select your choice 1.Add Employee 2.Get all employees 3.Eet emp id 4.exit");
			choice=sc.nextInt();
			switch (choice)
			{
			case 1:{
					System.out.println("Enter Employee Details name,salary,id");
					name=sc.next();
					salary=sc.nextInt();
					id=sc.nextInt();
					e=new Employee(name,salary,id);
					a.addEmployee(e);
					break;
					}
			case 2: {
					ArrayList<Employee> al=new ArrayList<Employee>();
					al=a.getAllEmp();
					 Iterator<Employee> i=al.iterator();
					    while(i.hasNext())
					    {
					    	e=(Employee) i.next();
					    	System.out.println(e);
					    }
					    break;
					   }
			case 3: {
						System.out.println("Enter id of employee");
						id=sc.nextInt();
						e=a.getEmpbyId(id);
						System.out.println(e);
						break;
					}
			default : if (choice!=4)
						System.out.println("Enter correct choice !!");	
					
			}
		}while(choice!=4);
		
		
		
	}
}
