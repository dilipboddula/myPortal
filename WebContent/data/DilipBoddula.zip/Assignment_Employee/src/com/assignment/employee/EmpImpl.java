package com.assignment.employee;

import java.util.ArrayList;
import java.util.Iterator;

public class EmpImpl implements EmployeeDetails 
{

	ArrayList<Employee> al= new ArrayList();
	
	@Override
	public boolean addEmployee(Employee e) {
		
		al.add(e);		
		if (e==null)			
			{return false;}
		else return true;
	}

	@Override
	public ArrayList<Employee> getAllEmp() {		
		return al;
	}

	@Override
	public Employee getEmpbyId(int id) {
		Employee e;
		Iterator<Employee> i=al.iterator();
	    while(i.hasNext())
	    {
	    	e=i.next();
	    	if(e.id==id)
	    	{
	    		return e;
	    	}
	    	else continue;
	    }
		return null;
	}
	
}
