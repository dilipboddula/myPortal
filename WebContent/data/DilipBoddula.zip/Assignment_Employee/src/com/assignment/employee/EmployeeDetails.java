package com.assignment.employee;

import java.util.ArrayList;

public interface EmployeeDetails 
{
	boolean addEmployee(Employee e);
	ArrayList<Employee> getAllEmp();
	Employee getEmpbyId(int id);
}
