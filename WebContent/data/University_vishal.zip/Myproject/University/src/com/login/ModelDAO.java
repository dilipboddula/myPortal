package com.login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class ModelDAO {
	

		static Connection con=null;
	public static Connection connectdb(){
		String drivername="com.mysql.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/project";
		String name="root";
		String password="root";
		try{
			Class.forName(drivername);
			con=DriverManager.getConnection(url,name,password);
			
			
		
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}catch(SQLException e){
			e.printStackTrace();
		}

		return con;

		}
	static void closedb(){
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	}


