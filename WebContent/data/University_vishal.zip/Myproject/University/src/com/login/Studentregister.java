package com.login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.PreparedStatement;

/**
 * Servlet implementation class Studentregister
 */
@WebServlet("/Studentregister")
public class Studentregister extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Connection connection;
	 String q="insert into studentdetails (studentname,studentusername,studentcourse,studentpnumber,studentemail,studentpassword) values (?,?,?,?,?,?)";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Studentregister() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd=null;
		 connection = ModelDAO.connectdb();
		 
		 PreparedStatement ps ;
		 String page=null;
		 try {
			
			ps=(PreparedStatement) connection.prepareStatement(q);
			ps.setString(1, request.getParameter("name"));
			ps.setString(2, request.getParameter("username"));
			ps.setString(3, request.getParameter("selectcourse"));
			ps.setString(4, (request.getParameter("pnumber")));
			ps.setString(5, request.getParameter("email"));
			ps.setString(6, request.getParameter("password"));
		 ps.executeUpdate();
		
			rd=request.getRequestDispatcher("index.jsp");
			rd.forward(request, response);
		 } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
		 }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
