package com.login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.PreparedStatement;

/**
 * Servlet implementation class Updateintable
 */
@WebServlet("/Updateintable")
public class Updateintable extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Connection connection;
	//String query="update studentmarks set "+usubject+"=?) where (studentid=?) and (semester=?)";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Updateintable() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		
		int marks=Integer.parseInt(request.getParameter("marks"));
		int uid=Integer.parseInt( (String) session.getAttribute("uid"));
		int usem=Integer.parseInt( (String) session.getAttribute("usem"));
		String usubject=(String) session.getAttribute("usubject");
		System.out.println(marks+" "+uid+" "+usem+" "+usubject);
		RequestDispatcher rd=null;
		 connection = ModelDAO.connectdb();
		 
		 PreparedStatement ps ;
		 String page=null;
		 try {
			
			ps=(PreparedStatement) connection.prepareStatement("update studentmarks set "+usubject+"=? where (studentid=?) and (semester=?)");
		
			ps.setInt(1, marks);
			ps.setInt(2, uid);
			ps.setInt(3, usem);
			
		 ps.executeUpdate();
		
			rd=request.getRequestDispatcher("profsuccess.jsp");
			rd.forward(request, response);
		 } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
		 }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
