package com.login;

public class Student {
	static String course;

	public static String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}
	

}
