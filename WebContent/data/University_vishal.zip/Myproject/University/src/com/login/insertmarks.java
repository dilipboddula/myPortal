package com.login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.PreparedStatement;
import com.login.*;

/**
 * Servlet implementation class insertmarks
 */
@WebServlet("/insertmarks")
public class insertmarks extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Connection connection;
	//String query="update studentmarks set semester=?,subject1marks=?,subject2marks=?,subject3marks=?,subject4marks=?,subject5marks=? where (studentid=?) and (studentcourse=?)";
       String q="insert into studentmarks(studentid,studentcourse,semester,subject1marks,subject2marks,subject3marks,subject4marks,subject5marks) values (?,?,?,?,?,?,?,?)";
    /**
     * @see HttpServlet#HttpServlet()
     */
    public insertmarks() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		System.out.println("hello");
		int marks1=Integer.parseInt(request.getParameter("marks1"));
		int marks2=Integer.parseInt(request.getParameter("marks2"));
		int marks3=Integer.parseInt(request.getParameter("marks3"));
		int marks4=Integer.parseInt(request.getParameter("marks4"));
		int marks5=Integer.parseInt(request.getParameter("marks5"));
		int uid=Integer.parseInt( (String) session.getAttribute("uid"));
		String usem=(String) session.getAttribute("usem");
		int useme=Integer.parseInt(usem);
		String uc=(String) Student.getCourse();
		System.out.println(marks1+" "+marks2+" "+marks3+" "+marks4+" "+marks5+" "+uid+" "+usem+" "+uc);
		RequestDispatcher rd=null;
		 connection = ModelDAO.connectdb();
		 
		 PreparedStatement ps ;
		 String page=null;
		 try {
			
			ps=(PreparedStatement) connection.prepareStatement(q);
			ps.setInt(1, uid);
			ps.setString(2, uc);
			ps.setInt(3, useme);
			ps.setInt(4, marks1);
			ps.setInt(5, marks2);
			ps.setInt(6, marks3);
			ps.setInt(7, marks4);
			ps.setInt(8,marks5);
		
		 ps.executeUpdate();
		
			rd=request.getRequestDispatcher("profsuccess.jsp");
			rd.forward(request, response);
		 } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
		 }
			}
			
		
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
