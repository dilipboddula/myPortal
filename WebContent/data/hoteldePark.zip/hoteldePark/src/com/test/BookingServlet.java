package com.test;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

 

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class register
 */
@WebServlet({ "/Bookingservlet"})
public class BookingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BookingServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    
    static Connection con;
   
    String insertquery="insert into bookingdata(username,cin,cout,nod,nr,category) values(?,?,?,?,?,?)";
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out=response.getWriter();
		
		
		HttpSession session = request.getSession();
		
		String myusername=(String) session.getAttribute("uzname");
		String mycin=request.getParameter("cin");
		String mycout=request.getParameter("cout");
		String mynod=request.getParameter("nod");
		String mynr=request.getParameter("nr");
		String mycategory=request.getParameter("category");
		 
		  
			con=ModelDAO.connectDB();
			
			PreparedStatement ps2;
			try
			  {
				ps2=con.prepareStatement(insertquery);
				
				ps2.setString(1,myusername);
	            ps2.setString(2,mycin);
	            ps2.setString(3,mycout);
	             
	            ps2.setString(4, mynod);
	            ps2.setString(5, mynr);
	            ps2.setString(6, mycategory);
	            
	            ps2.execute();
	           session.invalidate();
	            
	            
	           RequestDispatcher rd=request.getRequestDispatcher("booksuccess.jsp");
	            rd.include(request, response);
	            //RequestDispatcher rd=request.getRequestDispatcher("index.html");
	            //rd.include(request, response);
			  }

			catch(SQLException e)
			  {
				e.printStackTrace();
			  }
  
	}
		 
 

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
