package com.test;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
 

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

  
 
@WebServlet({ "/userServlet"})
public class userServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public userServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    
    static Connection conn;
    String matchUsernameQuery="select fname,pwd from user_registration where fname=?";
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	HttpSession session = request.getSession();
	PrintWriter out=response.getWriter();
	response.setContentType("text/html");
	
	String usrnm=request.getParameter("uname");
	String pswd=request.getParameter("pwd");

	
    conn=ModelDAO.connectDB();
	
	PreparedStatement ps1;
	int success=0;
	String username="a1@centralmail.com";
	String password="abc***";
	
	try
	  {
		ps1=conn.prepareStatement(matchUsernameQuery);
		ps1.setString(1, usrnm);
		ResultSet rs=ps1.executeQuery();
		while (rs.next()) 
            {
			 username=rs.getString(1);
			 password=rs.getString(2);
		
	        }
		if(username.equalsIgnoreCase(usrnm) && password.equalsIgnoreCase(pswd))
		    {
			 success=1;
		    }
	  }
	catch(SQLException e)
	  {
		e.printStackTrace();
	  }
	
	if(success==1)
	   {
		session.setAttribute("uzname", usrnm);
		RequestDispatcher rd=request.getRequestDispatcher("booking.jsp");
		rd.include(request, response);
	   }
	else
	   {
		response.sendRedirect("error.jsp");
            
	   }

}
 

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	   {
		
	   }

}
