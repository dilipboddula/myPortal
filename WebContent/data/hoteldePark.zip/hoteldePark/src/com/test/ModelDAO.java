package com.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ModelDAO
{
	static Connection con;
	public static Connection connectDB(){
    try {
       String drivername="com.mysql.jdbc.Driver";
       Class.forName(drivername).newInstance();
       con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hotelbooking","root","root");
        } catch (InstantiationException e) {
         
         e.printStackTrace();
         } catch (IllegalAccessException e) {
            
              e.printStackTrace();
              } catch (ClassNotFoundException e) {
               
           e.printStackTrace();
           } catch (SQLException e) {
        
               e.printStackTrace();
}
return con;
}
}

